INSERT INTO webandpr_vvTjz1Bk.w47fa_alm (id, name, repeaterDefault, repeaterType, pluginVersion) VALUES (1, 'default', '<li class="grid-item"> 
   <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
      <?php the_post_thumbnail(''alm-cta''); ?>
   </a>
   <h3>
      <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
         <?php the_title(); ?>
      </a>
   </h3>
   <?php the_excerpt(); ?>
   <div class="launch">
      <a href="<?php the_permalink(); ?>">Más...</a>
   </div> 
</li>', 'default', '3.5.0');