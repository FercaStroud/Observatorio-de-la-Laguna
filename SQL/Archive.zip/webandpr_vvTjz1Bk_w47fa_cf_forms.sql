INSERT INTO webandpr_vvTjz1Bk.w47fa_cf_forms (id, form_id, type, config) VALUES (1, 'CF55ccb68ca64c0', 'revision', 'a:24:{s:2:"ID";s:15:"CF55ccb68ca64c0";s:10:"cf_version";s:7:"1.5.7.1";s:7:"success";s:236:"<img src="http://traductoressimultaneos.com/wp-content/uploads/aceptado.png" alt="aceptado" width="52" height="52" class="alignleft size-full wp-image-67" />Gracias, el correo fue enviado correctamente.             																					";s:10:"db_support";i:0;s:6:"pinned";i:0;s:9:"hide_form";i:1;s:11:"check_honey";i:1;s:12:"avatar_field";s:0:"";s:9:"form_ajax";i:1;s:11:"layout_grid";a:2:{s:6:"fields";a:6:{s:11:"fld_1182857";s:3:"1:1";s:11:"fld_1812363";s:3:"1:1";s:11:"fld_9020497";s:3:"1:1";s:11:"fld_3421996";s:3:"2:1";s:11:"fld_4093740";s:3:"3:1";s:11:"fld_6033805";s:3:"4:1";}s:9:"structure";s:11:"12|12|12|12";}s:6:"fields";a:6:{s:11:"fld_1182857";a:8:{s:2:"ID";s:11:"fld_1182857";s:4:"type";s:4:"text";s:5:"label";s:6:"Nombre";s:4:"slug";s:6:"nombre";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:5:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:13:"type_override";s:4:"text";s:4:"mask";s:0:"";}}s:11:"fld_1812363";a:8:{s:2:"ID";s:11:"fld_1812363";s:4:"type";s:5:"radio";s:5:"label";s:15:"Elige la ciudad";s:4:"slug";s:6:"ciudad";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:11:{s:12:"custom_class";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:5:"count";s:12:"orderby_post";s:2:"ID";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:6:"option";a:2:{s:10:"opt1797486";a:3:{s:10:"calc_value";i:1;s:5:"value";s:9:"Monterrey";s:5:"label";s:9:"Monterrey";}s:10:"opt1300387";a:3:{s:10:"calc_value";i:1;s:5:"value";s:8:"Torreón";s:5:"label";s:8:"Torreón";}}}}s:11:"fld_3421996";a:8:{s:2:"ID";s:11:"fld_3421996";s:4:"type";s:5:"email";s:5:"label";s:6:"Correo";s:4:"slug";s:5:"email";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:3:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";}}s:11:"fld_4093740";a:8:{s:2:"ID";s:11:"fld_4093740";s:4:"type";s:9:"paragraph";s:5:"label";s:11:"Comentarios";s:4:"slug";s:11:"comentarios";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";i:3;s:7:"default";s:0:"";}}s:11:"fld_6033805";a:7:{s:2:"ID";s:11:"fld_6033805";s:4:"type";s:6:"button";s:5:"label";s:6:"Enviar";s:4:"slug";s:6:"enviar";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:4:"type";s:6:"submit";s:5:"class";s:15:"btn btn-default";s:6:"target";s:0:"";}}s:11:"fld_9020497";a:8:{s:2:"ID";s:11:"fld_9020497";s:4:"type";s:8:"dropdown";s:5:"label";s:6:"Asunto";s:4:"slug";s:12:"departamento";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:13:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:11:"show_values";i:1;s:6:"option";a:4:{s:10:"opt1716407";a:3:{s:10:"calc_value";i:1;s:5:"value";s:6:"Ventas";s:5:"label";s:21:"Ventas / Información";}s:10:"opt1259417";a:3:{s:10:"calc_value";i:1;s:5:"value";s:5:"Dudas";s:5:"label";s:5:"Dudas";}s:10:"opt1503008";a:3:{s:10:"calc_value";i:1;s:5:"value";s:10:"Sugerencia";s:5:"label";s:11:"Sugerencias";}s:10:"opt1766768";a:3:{s:10:"calc_value";i:1;s:5:"value";s:4:"Otro";s:5:"label";s:4:"Otro";}}}}}s:18:"conditional_groups";a:1:{s:15:"_open_condition";s:0:"";}s:10:"page_names";a:1:{i:0;s:6:"Page 1";}s:8:"settings";a:1:{s:10:"responsive";a:1:{s:11:"break_point";s:2:"sm";}}s:10:"processors";a:1:{s:11:"fp_78727378";a:5:{s:2:"ID";s:11:"fp_78727378";s:8:"runtimes";a:1:{s:6:"insert";i:1;}s:4:"type";s:14:"auto_responder";s:6:"config";a:9:{s:11:"sender_name";s:24:"Traductores Simultáneos";s:12:"sender_email";s:35:"contacto@traductoressimultaneos.com";s:8:"reply_to";s:0:"";s:2:"cc";s:0:"";s:3:"bcc";s:0:"";s:7:"subject";s:45:"Traductores Simultáneos / Tu correo recibido";s:14:"recipient_name";s:8:"%nombre%";s:15:"recipient_email";s:7:"%email%";s:7:"message";s:368:"A continuación, los datos recibidos. <strong>www.traductoressimultaneos.com
</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Ciudad: </strong>%ciudad%

<strong>Asunto: </strong>%departamento%

<strong>SKU: </strong>%sku%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"conditions";a:1:{s:4:"type";s:0:"";}}}s:4:"name";s:8:"Contacto";s:6:"mailer";a:9:{s:9:"on_insert";i:1;s:11:"sender_name";s:8:"%nombre%";s:12:"sender_email";s:37:"formulario@traductoressimultaneos.com";s:8:"reply_to";s:35:"contacto@traductoressimultaneos.com";s:10:"email_type";s:4:"html";s:10:"recipients";s:35:"contacto@traductoressimultaneos.com";s:6:"bcc_to";s:0:"";s:13:"email_subject";s:65:"Formulario / %ciudad% / %departamento% / Traductores Simultáneos";s:13:"email_message";s:357:"A continuación, los datos del formulario de contacto en <strong>www.traductoressimultaneos.com</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Ciudad: </strong>%ciudad%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:6:"hidden";i:1;s:10:"form_draft";i:0;s:4:"type";s:7:"primary";s:13:"_last_updated";s:31:"Wed, 16 May 2018 17:42:15 +0000";s:10:"scroll_top";i:0;s:15:"custom_callback";s:0:"";s:7:"version";s:5:"1.6.3";}');
INSERT INTO webandpr_vvTjz1Bk.w47fa_cf_forms (id, form_id, type, config) VALUES (2, 'CF55ccb68ca64c0', 'revision', 'a:22:{s:13:"_last_updated";s:31:"Wed, 16 May 2018 17:42:25 +0000";s:2:"ID";s:15:"CF55ccb68ca64c0";s:10:"cf_version";s:5:"1.6.3";s:4:"name";s:8:"Contacto";s:10:"scroll_top";i:0;s:7:"success";s:239:"<img src="http://traductoressimultaneos.com/wp-content/uploads/aceptado.png" alt="aceptado" width="52" height="52" class="alignleft size-full wp-image-67" />Gracias, el correo fue enviado correctamente.             																								";s:10:"db_support";i:0;s:6:"pinned";i:0;s:9:"hide_form";i:1;s:11:"check_honey";i:1;s:12:"avatar_field";N;s:9:"form_ajax";i:1;s:15:"custom_callback";s:0:"";s:11:"layout_grid";a:2:{s:6:"fields";a:6:{s:11:"fld_1182857";s:3:"1:1";s:11:"fld_1812363";s:3:"1:1";s:11:"fld_9020497";s:3:"1:1";s:11:"fld_3421996";s:3:"2:1";s:11:"fld_4093740";s:3:"3:1";s:11:"fld_6033805";s:3:"4:1";}s:9:"structure";s:11:"12|12|12|12";}s:6:"fields";a:6:{s:11:"fld_1182857";a:8:{s:2:"ID";s:11:"fld_1182857";s:4:"type";s:4:"text";s:5:"label";s:6:"Nombre";s:4:"slug";s:6:"nombre";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:5:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:13:"type_override";s:4:"text";s:4:"mask";s:0:"";}}s:11:"fld_1812363";a:8:{s:2:"ID";s:11:"fld_1812363";s:4:"type";s:5:"radio";s:5:"label";s:15:"Elige la ciudad";s:4:"slug";s:6:"ciudad";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:11:{s:12:"custom_class";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:6:"option";a:2:{s:10:"opt1797486";a:3:{s:10:"calc_value";s:9:"Monterrey";s:5:"value";s:9:"Monterrey";s:5:"label";s:9:"Monterrey";}s:10:"opt1300387";a:3:{s:10:"calc_value";s:8:"Torreón";s:5:"value";s:8:"Torreón";s:5:"label";s:8:"Torreón";}}}}s:11:"fld_9020497";a:8:{s:2:"ID";s:11:"fld_9020497";s:4:"type";s:8:"dropdown";s:5:"label";s:6:"Asunto";s:4:"slug";s:12:"departamento";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:13:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:11:"show_values";i:1;s:6:"option";a:4:{s:10:"opt1716407";a:3:{s:10:"calc_value";i:1;s:5:"value";s:6:"Ventas";s:5:"label";s:21:"Ventas / Información";}s:10:"opt1259417";a:3:{s:10:"calc_value";i:1;s:5:"value";s:5:"Dudas";s:5:"label";s:5:"Dudas";}s:10:"opt1503008";a:3:{s:10:"calc_value";i:1;s:5:"value";s:10:"Sugerencia";s:5:"label";s:11:"Sugerencias";}s:10:"opt1766768";a:3:{s:10:"calc_value";i:1;s:5:"value";s:4:"Otro";s:5:"label";s:4:"Otro";}}}}s:11:"fld_3421996";a:8:{s:2:"ID";s:11:"fld_3421996";s:4:"type";s:5:"email";s:5:"label";s:6:"Correo";s:4:"slug";s:5:"email";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:3:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";}}s:11:"fld_4093740";a:8:{s:2:"ID";s:11:"fld_4093740";s:4:"type";s:9:"paragraph";s:5:"label";s:11:"Comentarios";s:4:"slug";s:11:"comentarios";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";i:3;s:7:"default";s:0:"";}}s:11:"fld_6033805";a:7:{s:2:"ID";s:11:"fld_6033805";s:4:"type";s:6:"button";s:5:"label";s:6:"Enviar";s:4:"slug";s:6:"enviar";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:4:"type";s:6:"submit";s:5:"class";s:15:"btn btn-default";s:6:"target";s:0:"";}}}s:10:"page_names";a:1:{i:0;s:6:"Page 1";}s:6:"mailer";a:9:{s:9:"on_insert";i:1;s:11:"sender_name";s:8:"%nombre%";s:12:"sender_email";s:37:"formulario@traductoressimultaneos.com";s:8:"reply_to";s:35:"contacto@traductoressimultaneos.com";s:10:"email_type";s:4:"html";s:10:"recipients";s:35:"contacto@traductoressimultaneos.com";s:6:"bcc_to";s:0:"";s:13:"email_subject";s:65:"Formulario / %ciudad% / %departamento% / Traductores Simultáneos";s:13:"email_message";s:357:"A continuación, los datos del formulario de contacto en <strong>www.traductoressimultaneos.com</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Ciudad: </strong>%ciudad%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"processors";a:1:{s:11:"fp_78727378";a:5:{s:2:"ID";s:11:"fp_78727378";s:8:"runtimes";a:1:{s:6:"insert";i:1;}s:4:"type";s:14:"auto_responder";s:6:"config";a:9:{s:11:"sender_name";s:24:"Traductores Simultáneos";s:12:"sender_email";s:35:"contacto@traductoressimultaneos.com";s:8:"reply_to";s:0:"";s:2:"cc";s:0:"";s:3:"bcc";s:0:"";s:7:"subject";s:45:"Traductores Simultáneos / Tu correo recibido";s:14:"recipient_name";s:8:"%nombre%";s:15:"recipient_email";s:7:"%email%";s:7:"message";s:368:"A continuación, los datos recibidos. <strong>www.traductoressimultaneos.com
</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Ciudad: </strong>%ciudad%

<strong>Asunto: </strong>%departamento%

<strong>SKU: </strong>%sku%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"conditions";a:1:{s:4:"type";s:0:"";}}}s:8:"antispam";a:2:{s:11:"sender_name";s:0:"";s:12:"sender_email";s:0:"";}s:18:"conditional_groups";a:1:{s:15:"_open_condition";s:0:"";}s:8:"settings";a:1:{s:10:"responsive";a:1:{s:11:"break_point";s:2:"sm";}}s:7:"version";s:5:"1.6.3";}');
INSERT INTO webandpr_vvTjz1Bk.w47fa_cf_forms (id, form_id, type, config) VALUES (3, 'CF5afd94db8a6a4', 'primary', 'a:26:{s:13:"_last_updated";s:31:"Wed, 16 May 2018 17:42:25 +0000";s:2:"ID";s:15:"CF5afd94db8a6a4";s:10:"cf_version";s:5:"1.6.3";s:4:"name";s:17:"Contacto respaldo";s:10:"scroll_top";i:0;s:7:"success";s:53:"El formulario ha sido correctamente enviado. Gracias.";s:10:"db_support";i:1;s:6:"pinned";i:0;s:9:"hide_form";i:1;s:11:"check_honey";i:1;s:12:"avatar_field";N;s:9:"form_ajax";i:1;s:15:"custom_callback";s:0:"";s:11:"layout_grid";a:2:{s:6:"fields";a:6:{s:11:"fld_1182857";s:3:"1:1";s:11:"fld_1812363";s:3:"1:1";s:11:"fld_9020497";s:3:"1:1";s:11:"fld_3421996";s:3:"2:1";s:11:"fld_4093740";s:3:"3:1";s:11:"fld_6033805";s:3:"4:1";}s:9:"structure";s:11:"12|12|12|12";}s:6:"fields";a:6:{s:11:"fld_1182857";a:8:{s:2:"ID";s:11:"fld_1182857";s:4:"type";s:4:"text";s:5:"label";s:6:"Nombre";s:4:"slug";s:6:"nombre";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:5:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:13:"type_override";s:4:"text";s:4:"mask";s:0:"";}}s:11:"fld_1812363";a:8:{s:2:"ID";s:11:"fld_1812363";s:4:"type";s:5:"radio";s:5:"label";s:15:"Elige la ciudad";s:4:"slug";s:6:"ciudad";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:11:{s:12:"custom_class";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:6:"option";a:2:{s:10:"opt1797486";a:3:{s:10:"calc_value";s:9:"Monterrey";s:5:"value";s:9:"Monterrey";s:5:"label";s:9:"Monterrey";}s:10:"opt1300387";a:3:{s:10:"calc_value";s:8:"Torreón";s:5:"value";s:8:"Torreón";s:5:"label";s:8:"Torreón";}}}}s:11:"fld_9020497";a:8:{s:2:"ID";s:11:"fld_9020497";s:4:"type";s:8:"dropdown";s:5:"label";s:6:"Asunto";s:4:"slug";s:12:"departamento";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:13:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:11:"show_values";i:1;s:6:"option";a:4:{s:10:"opt1716407";a:3:{s:10:"calc_value";i:1;s:5:"value";s:6:"Ventas";s:5:"label";s:21:"Ventas / Información";}s:10:"opt1259417";a:3:{s:10:"calc_value";i:1;s:5:"value";s:5:"Dudas";s:5:"label";s:5:"Dudas";}s:10:"opt1503008";a:3:{s:10:"calc_value";i:1;s:5:"value";s:10:"Sugerencia";s:5:"label";s:11:"Sugerencias";}s:10:"opt1766768";a:3:{s:10:"calc_value";i:1;s:5:"value";s:4:"Otro";s:5:"label";s:4:"Otro";}}}}s:11:"fld_3421996";a:8:{s:2:"ID";s:11:"fld_3421996";s:4:"type";s:5:"email";s:5:"label";s:6:"Correo";s:4:"slug";s:5:"email";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:3:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";}}s:11:"fld_4093740";a:8:{s:2:"ID";s:11:"fld_4093740";s:4:"type";s:9:"paragraph";s:5:"label";s:11:"Comentarios";s:4:"slug";s:11:"comentarios";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";i:3;s:7:"default";s:0:"";}}s:11:"fld_6033805";a:7:{s:2:"ID";s:11:"fld_6033805";s:4:"type";s:6:"button";s:5:"label";s:6:"Enviar";s:4:"slug";s:6:"enviar";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:4:"type";s:6:"submit";s:5:"class";s:15:"btn btn-default";s:6:"target";s:0:"";}}}s:10:"page_names";a:1:{i:0;s:6:"Page 1";}s:6:"mailer";a:1:{s:9:"on_insert";i:1;}s:10:"processors";a:1:{s:11:"fp_78727378";a:5:{s:2:"ID";s:11:"fp_78727378";s:8:"runtimes";a:1:{s:6:"insert";i:1;}s:4:"type";s:14:"auto_responder";s:6:"config";a:9:{s:11:"sender_name";s:24:"Traductores Simultáneos";s:12:"sender_email";s:35:"contacto@traductoressimultaneos.com";s:8:"reply_to";s:0:"";s:2:"cc";s:0:"";s:3:"bcc";s:0:"";s:7:"subject";s:45:"Traductores Simultáneos / Tu correo recibido";s:14:"recipient_name";s:8:"%nombre%";s:15:"recipient_email";s:7:"%email%";s:7:"message";s:368:"A continuación, los datos recibidos. <strong>www.traductoressimultaneos.com
</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Ciudad: </strong>%ciudad%

<strong>Asunto: </strong>%departamento%

<strong>SKU: </strong>%sku%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"conditions";a:1:{s:4:"type";s:0:"";}}}s:8:"antispam";a:2:{s:11:"sender_name";s:0:"";s:12:"sender_email";s:0:"";}s:18:"conditional_groups";a:1:{s:15:"_open_condition";s:0:"";}s:8:"settings";a:1:{s:10:"responsive";a:1:{s:11:"break_point";s:2:"sm";}}s:7:"version";s:5:"1.6.3";s:4:"type";s:7:"primary";s:11:"description";s:0:"";s:5:"nonce";s:10:"1fcaae3345";s:5:"clone";s:15:"CF55ccb68ca64c0";}');
INSERT INTO webandpr_vvTjz1Bk.w47fa_cf_forms (id, form_id, type, config) VALUES (4, 'CF55ccb68ca64c0', 'revision', 'a:22:{s:13:"_last_updated";s:31:"Thu, 17 May 2018 14:45:34 +0000";s:2:"ID";s:15:"CF55ccb68ca64c0";s:10:"cf_version";s:5:"1.6.3";s:4:"name";s:8:"Contacto";s:10:"scroll_top";i:0;s:7:"success";s:242:"<img src="http://traductoressimultaneos.com/wp-content/uploads/aceptado.png" alt="aceptado" width="52" height="52" class="alignleft size-full wp-image-67" />Gracias, el correo fue enviado correctamente.             																											";s:10:"db_support";i:0;s:6:"pinned";i:0;s:9:"hide_form";i:1;s:11:"check_honey";i:1;s:12:"avatar_field";s:0:"";s:9:"form_ajax";i:1;s:15:"custom_callback";s:0:"";s:11:"layout_grid";a:2:{s:6:"fields";a:5:{s:11:"fld_1182857";s:3:"1:1";s:11:"fld_9020497";s:3:"1:1";s:11:"fld_3421996";s:3:"2:1";s:11:"fld_4093740";s:3:"3:1";s:11:"fld_6033805";s:3:"4:1";}s:9:"structure";s:11:"12|12|12|12";}s:6:"fields";a:5:{s:11:"fld_1182857";a:8:{s:2:"ID";s:11:"fld_1182857";s:4:"type";s:4:"text";s:5:"label";s:6:"Nombre";s:4:"slug";s:6:"nombre";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:5:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:13:"type_override";s:4:"text";s:4:"mask";s:0:"";}}s:11:"fld_9020497";a:8:{s:2:"ID";s:11:"fld_9020497";s:4:"type";s:8:"dropdown";s:5:"label";s:6:"Asunto";s:4:"slug";s:12:"departamento";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:13:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:11:"show_values";i:1;s:6:"option";a:4:{s:10:"opt1716407";a:3:{s:10:"calc_value";i:1;s:5:"value";s:6:"Ventas";s:5:"label";s:21:"Ventas / Información";}s:10:"opt1259417";a:3:{s:10:"calc_value";i:1;s:5:"value";s:5:"Dudas";s:5:"label";s:5:"Dudas";}s:10:"opt1503008";a:3:{s:10:"calc_value";i:1;s:5:"value";s:10:"Sugerencia";s:5:"label";s:11:"Sugerencias";}s:10:"opt1766768";a:3:{s:10:"calc_value";i:1;s:5:"value";s:4:"Otro";s:5:"label";s:4:"Otro";}}}}s:11:"fld_3421996";a:8:{s:2:"ID";s:11:"fld_3421996";s:4:"type";s:5:"email";s:5:"label";s:6:"Correo";s:4:"slug";s:5:"email";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:3:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";}}s:11:"fld_4093740";a:8:{s:2:"ID";s:11:"fld_4093740";s:4:"type";s:9:"paragraph";s:5:"label";s:11:"Comentarios";s:4:"slug";s:11:"comentarios";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";i:3;s:7:"default";s:0:"";}}s:11:"fld_6033805";a:7:{s:2:"ID";s:11:"fld_6033805";s:4:"type";s:6:"button";s:5:"label";s:6:"Enviar";s:4:"slug";s:6:"enviar";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:4:"type";s:6:"submit";s:5:"class";s:15:"btn btn-default";s:6:"target";s:0:"";}}}s:10:"page_names";a:1:{i:0;s:6:"Page 1";}s:6:"mailer";a:9:{s:9:"on_insert";i:1;s:11:"sender_name";s:8:"%nombre%";s:12:"sender_email";s:40:"formulario@observatoriodelalaguna.org.mx";s:8:"reply_to";s:38:"contacto@observatoriodelalaguna.org.mx";s:10:"email_type";s:4:"html";s:10:"recipients";s:38:"contacto@observatoriodelalaguna.org.mx";s:6:"bcc_to";s:0:"";s:13:"email_subject";s:55:"Formulario / %departamento% / Observatorio de La Laguna";s:13:"email_message";s:325:"A continuación, los datos del formulario de contacto en <strong>www.observatoriodelalaguna.org.mx</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"processors";a:1:{s:11:"fp_78727378";a:5:{s:2:"ID";s:11:"fp_78727378";s:8:"runtimes";a:1:{s:6:"insert";i:1;}s:4:"type";s:14:"auto_responder";s:6:"config";a:9:{s:11:"sender_name";s:24:"Traductores Simultáneos";s:12:"sender_email";s:35:"contacto@traductoressimultaneos.com";s:8:"reply_to";s:0:"";s:2:"cc";s:0:"";s:3:"bcc";s:0:"";s:7:"subject";s:45:"Traductores Simultáneos / Tu correo recibido";s:14:"recipient_name";s:8:"%nombre%";s:15:"recipient_email";s:7:"%email%";s:7:"message";s:368:"A continuación, los datos recibidos. <strong>www.traductoressimultaneos.com
</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Ciudad: </strong>%ciudad%

<strong>Asunto: </strong>%departamento%

<strong>SKU: </strong>%sku%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"conditions";a:1:{s:4:"type";s:0:"";}}}s:8:"antispam";a:2:{s:11:"sender_name";s:0:"";s:12:"sender_email";s:0:"";}s:18:"conditional_groups";a:1:{s:15:"_open_condition";s:0:"";}s:8:"settings";a:1:{s:10:"responsive";a:1:{s:11:"break_point";s:2:"sm";}}s:7:"version";s:5:"1.6.3";}');
INSERT INTO webandpr_vvTjz1Bk.w47fa_cf_forms (id, form_id, type, config) VALUES (5, 'CF55ccb68ca64c0', 'revision', 'a:22:{s:13:"_last_updated";s:31:"Thu, 17 May 2018 14:46:37 +0000";s:2:"ID";s:15:"CF55ccb68ca64c0";s:10:"cf_version";s:5:"1.6.3";s:4:"name";s:8:"Contacto";s:10:"scroll_top";i:0;s:7:"success";s:242:"<img src="http://traductoressimultaneos.com/wp-content/uploads/aceptado.png" alt="aceptado" width="52" height="52" class="alignleft size-full wp-image-67" />Gracias, el correo fue enviado correctamente.             																											";s:10:"db_support";i:0;s:6:"pinned";i:0;s:9:"hide_form";i:1;s:11:"check_honey";i:1;s:12:"avatar_field";s:0:"";s:9:"form_ajax";i:1;s:15:"custom_callback";s:0:"";s:11:"layout_grid";a:2:{s:6:"fields";a:5:{s:11:"fld_1182857";s:3:"1:1";s:11:"fld_9020497";s:3:"1:1";s:11:"fld_3421996";s:3:"2:1";s:11:"fld_4093740";s:3:"3:1";s:11:"fld_6033805";s:3:"4:1";}s:9:"structure";s:11:"12|12|12|12";}s:6:"fields";a:5:{s:11:"fld_1182857";a:8:{s:2:"ID";s:11:"fld_1182857";s:4:"type";s:4:"text";s:5:"label";s:6:"Nombre";s:4:"slug";s:6:"nombre";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:5:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:13:"type_override";s:4:"text";s:4:"mask";s:0:"";}}s:11:"fld_9020497";a:8:{s:2:"ID";s:11:"fld_9020497";s:4:"type";s:8:"dropdown";s:5:"label";s:6:"Asunto";s:4:"slug";s:12:"departamento";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:13:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:11:"show_values";i:1;s:6:"option";a:4:{s:10:"opt1716407";a:3:{s:10:"calc_value";i:1;s:5:"value";s:6:"Ventas";s:5:"label";s:21:"Ventas / Información";}s:10:"opt1259417";a:3:{s:10:"calc_value";i:1;s:5:"value";s:5:"Dudas";s:5:"label";s:5:"Dudas";}s:10:"opt1503008";a:3:{s:10:"calc_value";i:1;s:5:"value";s:10:"Sugerencia";s:5:"label";s:11:"Sugerencias";}s:10:"opt1766768";a:3:{s:10:"calc_value";i:1;s:5:"value";s:4:"Otro";s:5:"label";s:4:"Otro";}}}}s:11:"fld_3421996";a:8:{s:2:"ID";s:11:"fld_3421996";s:4:"type";s:5:"email";s:5:"label";s:6:"Correo";s:4:"slug";s:5:"email";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:3:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";}}s:11:"fld_4093740";a:8:{s:2:"ID";s:11:"fld_4093740";s:4:"type";s:9:"paragraph";s:5:"label";s:11:"Comentarios";s:4:"slug";s:11:"comentarios";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";i:3;s:7:"default";s:0:"";}}s:11:"fld_6033805";a:7:{s:2:"ID";s:11:"fld_6033805";s:4:"type";s:6:"button";s:5:"label";s:6:"Enviar";s:4:"slug";s:6:"enviar";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:4:"type";s:6:"submit";s:5:"class";s:15:"btn btn-default";s:6:"target";s:0:"";}}}s:10:"page_names";a:1:{i:0;s:6:"Page 1";}s:6:"mailer";a:9:{s:9:"on_insert";i:1;s:11:"sender_name";s:8:"%nombre%";s:12:"sender_email";s:40:"formulario@observatoriodelalaguna.org.mx";s:8:"reply_to";s:38:"contacto@observatoriodelalaguna.org.mx";s:10:"email_type";s:4:"html";s:10:"recipients";s:38:"contacto@observatoriodelalaguna.org.mx";s:6:"bcc_to";s:0:"";s:13:"email_subject";s:55:"Formulario / %departamento% / Observatorio de La Laguna";s:13:"email_message";s:325:"A continuación, los datos del formulario de contacto en <strong>www.observatoriodelalaguna.org.mx</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"processors";a:1:{s:11:"fp_78727378";a:5:{s:2:"ID";s:11:"fp_78727378";s:8:"runtimes";a:1:{s:6:"insert";i:1;}s:4:"type";s:14:"auto_responder";s:6:"config";a:9:{s:11:"sender_name";s:25:"Observatorio de La Laguna";s:12:"sender_email";s:38:"contacto@observatoriodelalaguna.org.mx";s:8:"reply_to";s:0:"";s:2:"cc";s:0:"";s:3:"bcc";s:0:"";s:7:"subject";s:46:"Observatorio de La Laguna / Tu correo recibido";s:14:"recipient_name";s:8:"%nombre%";s:15:"recipient_email";s:7:"%email%";s:7:"message";s:336:"A continuación, los datos recibidos. <strong>www.observatoriodelalaguna.org.mx
</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>SKU: </strong>%sku%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"conditions";a:1:{s:4:"type";s:0:"";}}}s:8:"antispam";a:2:{s:11:"sender_name";s:0:"";s:12:"sender_email";s:0:"";}s:18:"conditional_groups";a:1:{s:15:"_open_condition";s:0:"";}s:8:"settings";a:1:{s:10:"responsive";a:1:{s:11:"break_point";s:2:"sm";}}s:7:"version";s:5:"1.6.3";}');
INSERT INTO webandpr_vvTjz1Bk.w47fa_cf_forms (id, form_id, type, config) VALUES (6, 'CF55ccb68ca64c0', 'revision', 'a:22:{s:13:"_last_updated";s:31:"Thu, 17 May 2018 14:47:05 +0000";s:2:"ID";s:15:"CF55ccb68ca64c0";s:10:"cf_version";s:5:"1.6.3";s:4:"name";s:8:"Contacto";s:10:"scroll_top";i:0;s:7:"success";s:242:"<img src="http://traductoressimultaneos.com/wp-content/uploads/aceptado.png" alt="aceptado" width="52" height="52" class="alignleft size-full wp-image-67" />Gracias, el correo fue enviado correctamente.             																											";s:10:"db_support";i:0;s:6:"pinned";i:0;s:9:"hide_form";i:1;s:11:"check_honey";i:1;s:12:"avatar_field";s:0:"";s:9:"form_ajax";i:1;s:15:"custom_callback";s:0:"";s:11:"layout_grid";a:2:{s:6:"fields";a:5:{s:11:"fld_1182857";s:3:"1:1";s:11:"fld_9020497";s:3:"1:1";s:11:"fld_3421996";s:3:"2:1";s:11:"fld_4093740";s:3:"3:1";s:11:"fld_6033805";s:3:"4:1";}s:9:"structure";s:11:"12|12|12|12";}s:6:"fields";a:5:{s:11:"fld_1182857";a:8:{s:2:"ID";s:11:"fld_1182857";s:4:"type";s:4:"text";s:5:"label";s:6:"Nombre";s:4:"slug";s:6:"nombre";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:5:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:13:"type_override";s:4:"text";s:4:"mask";s:0:"";}}s:11:"fld_9020497";a:8:{s:2:"ID";s:11:"fld_9020497";s:4:"type";s:8:"dropdown";s:5:"label";s:6:"Asunto";s:4:"slug";s:12:"departamento";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:13:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:11:"show_values";i:1;s:6:"option";a:4:{s:10:"opt1716407";a:3:{s:10:"calc_value";i:1;s:5:"value";s:6:"Ventas";s:5:"label";s:21:"Ventas / Información";}s:10:"opt1259417";a:3:{s:10:"calc_value";i:1;s:5:"value";s:5:"Dudas";s:5:"label";s:5:"Dudas";}s:10:"opt1503008";a:3:{s:10:"calc_value";i:1;s:5:"value";s:10:"Sugerencia";s:5:"label";s:11:"Sugerencias";}s:10:"opt1766768";a:3:{s:10:"calc_value";i:1;s:5:"value";s:4:"Otro";s:5:"label";s:4:"Otro";}}}}s:11:"fld_3421996";a:8:{s:2:"ID";s:11:"fld_3421996";s:4:"type";s:5:"email";s:5:"label";s:6:"Correo";s:4:"slug";s:5:"email";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:3:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";}}s:11:"fld_4093740";a:8:{s:2:"ID";s:11:"fld_4093740";s:4:"type";s:9:"paragraph";s:5:"label";s:11:"Comentarios";s:4:"slug";s:11:"comentarios";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";i:3;s:7:"default";s:0:"";}}s:11:"fld_6033805";a:7:{s:2:"ID";s:11:"fld_6033805";s:4:"type";s:6:"button";s:5:"label";s:6:"Enviar";s:4:"slug";s:6:"enviar";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:4:"type";s:6:"submit";s:5:"class";s:15:"btn btn-default";s:6:"target";s:0:"";}}}s:10:"page_names";a:1:{i:0;s:6:"Page 1";}s:6:"mailer";a:9:{s:9:"on_insert";i:1;s:11:"sender_name";s:8:"%nombre%";s:12:"sender_email";s:40:"formulario@observatoriodelalaguna.org.mx";s:8:"reply_to";s:38:"contacto@observatoriodelalaguna.org.mx";s:10:"email_type";s:4:"html";s:10:"recipients";s:38:"contacto@observatoriodelalaguna.org.mx";s:6:"bcc_to";s:0:"";s:13:"email_subject";s:55:"Formulario / %departamento% / Observatorio de La Laguna";s:13:"email_message";s:325:"A continuación, los datos del formulario de contacto en <strong>www.observatoriodelalaguna.org.mx</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"processors";a:1:{s:11:"fp_78727378";a:5:{s:2:"ID";s:11:"fp_78727378";s:8:"runtimes";a:1:{s:6:"insert";i:1;}s:4:"type";s:14:"auto_responder";s:6:"config";a:9:{s:11:"sender_name";s:25:"Observatorio de La Laguna";s:12:"sender_email";s:38:"contacto@observatoriodelalaguna.org.mx";s:8:"reply_to";s:0:"";s:2:"cc";s:0:"";s:3:"bcc";s:0:"";s:7:"subject";s:46:"Observatorio de La Laguna / Tu correo recibido";s:14:"recipient_name";s:8:"%nombre%";s:15:"recipient_email";s:7:"%email%";s:7:"message";s:336:"A continuación, los datos recibidos. <strong>www.observatoriodelalaguna.org.mx
</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>SKU: </strong>%sku%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"conditions";a:1:{s:4:"type";s:0:"";}}}s:8:"antispam";a:2:{s:11:"sender_name";s:0:"";s:12:"sender_email";s:0:"";}s:18:"conditional_groups";a:1:{s:15:"_open_condition";s:0:"";}s:8:"settings";a:1:{s:10:"responsive";a:1:{s:11:"break_point";s:2:"sm";}}s:7:"version";s:5:"1.6.3";}');
INSERT INTO webandpr_vvTjz1Bk.w47fa_cf_forms (id, form_id, type, config) VALUES (7, 'CF55ccb68ca64c0', 'revision', 'a:22:{s:13:"_last_updated";s:31:"Thu, 17 May 2018 14:47:39 +0000";s:2:"ID";s:15:"CF55ccb68ca64c0";s:10:"cf_version";s:5:"1.6.3";s:4:"name";s:8:"Contacto";s:10:"scroll_top";i:0;s:7:"success";s:245:"<img src="http://traductoressimultaneos.com/wp-content/uploads/aceptado.png" alt="aceptado" width="52" height="52" class="alignleft size-full wp-image-67" />Gracias, el correo fue enviado correctamente.             																														";s:10:"db_support";i:1;s:6:"pinned";i:0;s:9:"hide_form";i:1;s:11:"check_honey";i:1;s:12:"avatar_field";s:0:"";s:9:"form_ajax";i:1;s:15:"custom_callback";s:0:"";s:11:"layout_grid";a:2:{s:6:"fields";a:5:{s:11:"fld_1182857";s:3:"1:1";s:11:"fld_9020497";s:3:"1:1";s:11:"fld_3421996";s:3:"2:1";s:11:"fld_4093740";s:3:"3:1";s:11:"fld_6033805";s:3:"4:1";}s:9:"structure";s:11:"12|12|12|12";}s:6:"fields";a:5:{s:11:"fld_1182857";a:8:{s:2:"ID";s:11:"fld_1182857";s:4:"type";s:4:"text";s:5:"label";s:6:"Nombre";s:4:"slug";s:6:"nombre";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:5:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:13:"type_override";s:4:"text";s:4:"mask";s:0:"";}}s:11:"fld_9020497";a:8:{s:2:"ID";s:11:"fld_9020497";s:4:"type";s:8:"dropdown";s:5:"label";s:6:"Asunto";s:4:"slug";s:12:"departamento";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:13:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:11:"show_values";i:1;s:6:"option";a:4:{s:10:"opt1716407";a:3:{s:10:"calc_value";i:1;s:5:"value";s:6:"Ventas";s:5:"label";s:21:"Ventas / Información";}s:10:"opt1259417";a:3:{s:10:"calc_value";i:1;s:5:"value";s:5:"Dudas";s:5:"label";s:5:"Dudas";}s:10:"opt1503008";a:3:{s:10:"calc_value";i:1;s:5:"value";s:10:"Sugerencia";s:5:"label";s:11:"Sugerencias";}s:10:"opt1766768";a:3:{s:10:"calc_value";i:1;s:5:"value";s:4:"Otro";s:5:"label";s:4:"Otro";}}}}s:11:"fld_3421996";a:8:{s:2:"ID";s:11:"fld_3421996";s:4:"type";s:5:"email";s:5:"label";s:6:"Correo";s:4:"slug";s:5:"email";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:3:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";}}s:11:"fld_4093740";a:8:{s:2:"ID";s:11:"fld_4093740";s:4:"type";s:9:"paragraph";s:5:"label";s:11:"Comentarios";s:4:"slug";s:11:"comentarios";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";i:3;s:7:"default";s:0:"";}}s:11:"fld_6033805";a:7:{s:2:"ID";s:11:"fld_6033805";s:4:"type";s:6:"button";s:5:"label";s:6:"Enviar";s:4:"slug";s:6:"enviar";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:4:"type";s:6:"submit";s:5:"class";s:15:"btn btn-default";s:6:"target";s:0:"";}}}s:10:"page_names";a:1:{i:0;s:6:"Page 1";}s:6:"mailer";a:9:{s:9:"on_insert";i:1;s:11:"sender_name";s:8:"%nombre%";s:12:"sender_email";s:40:"formulario@observatoriodelalaguna.org.mx";s:8:"reply_to";s:38:"contacto@observatoriodelalaguna.org.mx";s:10:"email_type";s:4:"html";s:10:"recipients";s:38:"contacto@observatoriodelalaguna.org.mx";s:6:"bcc_to";s:0:"";s:13:"email_subject";s:55:"Formulario / %departamento% / Observatorio de La Laguna";s:13:"email_message";s:325:"A continuación, los datos del formulario de contacto en <strong>www.observatoriodelalaguna.org.mx</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"processors";a:1:{s:11:"fp_78727378";a:5:{s:2:"ID";s:11:"fp_78727378";s:8:"runtimes";a:1:{s:6:"insert";i:1;}s:4:"type";s:14:"auto_responder";s:6:"config";a:9:{s:11:"sender_name";s:25:"Observatorio de La Laguna";s:12:"sender_email";s:38:"contacto@observatoriodelalaguna.org.mx";s:8:"reply_to";s:0:"";s:2:"cc";s:0:"";s:3:"bcc";s:0:"";s:7:"subject";s:46:"Observatorio de La Laguna / Tu correo recibido";s:14:"recipient_name";s:8:"%nombre%";s:15:"recipient_email";s:7:"%email%";s:7:"message";s:336:"A continuación, los datos recibidos. <strong>www.observatoriodelalaguna.org.mx
</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>SKU: </strong>%sku%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"conditions";a:1:{s:4:"type";s:0:"";}}}s:8:"antispam";a:2:{s:11:"sender_name";s:0:"";s:12:"sender_email";s:0:"";}s:18:"conditional_groups";a:1:{s:15:"_open_condition";s:0:"";}s:8:"settings";a:1:{s:10:"responsive";a:1:{s:11:"break_point";s:2:"sm";}}s:7:"version";s:5:"1.6.3";}');
INSERT INTO webandpr_vvTjz1Bk.w47fa_cf_forms (id, form_id, type, config) VALUES (8, 'CF55ccb68ca64c0', 'revision', 'a:22:{s:13:"_last_updated";s:31:"Thu, 17 May 2018 14:50:02 +0000";s:2:"ID";s:15:"CF55ccb68ca64c0";s:10:"cf_version";s:5:"1.6.3";s:4:"name";s:8:"Contacto";s:10:"scroll_top";i:0;s:7:"success";s:248:"<img src="http://traductoressimultaneos.com/wp-content/uploads/aceptado.png" alt="aceptado" width="52" height="52" class="alignleft size-full wp-image-67" />Gracias, el correo fue enviado correctamente.             																																	";s:10:"db_support";i:1;s:6:"pinned";i:0;s:9:"hide_form";i:1;s:11:"check_honey";i:1;s:12:"avatar_field";N;s:9:"form_ajax";i:1;s:15:"custom_callback";s:0:"";s:11:"layout_grid";a:2:{s:6:"fields";a:5:{s:11:"fld_1182857";s:3:"1:1";s:11:"fld_9020497";s:3:"1:1";s:11:"fld_3421996";s:3:"2:1";s:11:"fld_4093740";s:3:"3:1";s:11:"fld_6033805";s:3:"4:1";}s:9:"structure";s:11:"12|12|12|12";}s:6:"fields";a:5:{s:11:"fld_1182857";a:8:{s:2:"ID";s:11:"fld_1182857";s:4:"type";s:4:"text";s:5:"label";s:6:"Nombre";s:4:"slug";s:6:"nombre";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:5:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:13:"type_override";s:4:"text";s:4:"mask";s:0:"";}}s:11:"fld_9020497";a:8:{s:2:"ID";s:11:"fld_9020497";s:4:"type";s:8:"dropdown";s:5:"label";s:6:"Asunto";s:4:"slug";s:12:"departamento";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:13:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:11:"show_values";i:1;s:6:"option";a:4:{s:10:"opt1259417";a:3:{s:10:"calc_value";i:1;s:5:"value";s:5:"Dudas";s:5:"label";s:5:"Dudas";}s:10:"opt1503008";a:3:{s:10:"calc_value";i:1;s:5:"value";s:10:"Sugerencia";s:5:"label";s:11:"Sugerencias";}s:10:"opt1716407";a:3:{s:10:"calc_value";i:1;s:5:"value";s:6:"Quejas";s:5:"label";s:6:"Quejas";}s:10:"opt1766768";a:3:{s:10:"calc_value";i:1;s:5:"value";s:4:"Otro";s:5:"label";s:4:"Otro";}}}}s:11:"fld_3421996";a:8:{s:2:"ID";s:11:"fld_3421996";s:4:"type";s:5:"email";s:5:"label";s:6:"Correo";s:4:"slug";s:5:"email";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:3:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";}}s:11:"fld_4093740";a:8:{s:2:"ID";s:11:"fld_4093740";s:4:"type";s:9:"paragraph";s:5:"label";s:11:"Comentarios";s:4:"slug";s:11:"comentarios";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";i:3;s:7:"default";s:0:"";}}s:11:"fld_6033805";a:7:{s:2:"ID";s:11:"fld_6033805";s:4:"type";s:6:"button";s:5:"label";s:6:"Enviar";s:4:"slug";s:6:"enviar";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:4:"type";s:6:"submit";s:5:"class";s:15:"btn btn-default";s:6:"target";s:0:"";}}}s:10:"page_names";a:1:{i:0;s:6:"Page 1";}s:6:"mailer";a:9:{s:9:"on_insert";i:1;s:11:"sender_name";s:8:"%nombre%";s:12:"sender_email";s:40:"formulario@observatoriodelalaguna.org.mx";s:8:"reply_to";s:38:"contacto@observatoriodelalaguna.org.mx";s:10:"email_type";s:4:"html";s:10:"recipients";s:38:"contacto@observatoriodelalaguna.org.mx";s:6:"bcc_to";s:0:"";s:13:"email_subject";s:55:"Formulario / %departamento% / Observatorio de La Laguna";s:13:"email_message";s:325:"A continuación, los datos del formulario de contacto en <strong>www.observatoriodelalaguna.org.mx</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"processors";a:1:{s:11:"fp_78727378";a:5:{s:2:"ID";s:11:"fp_78727378";s:8:"runtimes";a:1:{s:6:"insert";i:1;}s:4:"type";s:14:"auto_responder";s:6:"config";a:9:{s:11:"sender_name";s:25:"Observatorio de La Laguna";s:12:"sender_email";s:38:"contacto@observatoriodelalaguna.org.mx";s:8:"reply_to";s:0:"";s:2:"cc";s:0:"";s:3:"bcc";s:0:"";s:7:"subject";s:46:"Observatorio de La Laguna / Tu correo recibido";s:14:"recipient_name";s:8:"%nombre%";s:15:"recipient_email";s:7:"%email%";s:7:"message";s:336:"A continuación, los datos recibidos. <strong>www.observatoriodelalaguna.org.mx
</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>SKU: </strong>%sku%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"conditions";a:1:{s:4:"type";s:0:"";}}}s:8:"antispam";a:2:{s:11:"sender_name";s:0:"";s:12:"sender_email";s:0:"";}s:18:"conditional_groups";a:1:{s:15:"_open_condition";s:0:"";}s:8:"settings";a:1:{s:10:"responsive";a:1:{s:11:"break_point";s:2:"sm";}}s:7:"version";s:5:"1.6.3";}');
INSERT INTO webandpr_vvTjz1Bk.w47fa_cf_forms (id, form_id, type, config) VALUES (9, 'CF55ccb68ca64c0', 'revision', 'a:23:{s:13:"_last_updated";s:31:"Tue, 12 Jun 2018 03:55:17 +0000";s:2:"ID";s:15:"CF55ccb68ca64c0";s:10:"cf_version";s:7:"1.7.1.4";s:4:"name";s:8:"Contacto";s:10:"scroll_top";i:0;s:7:"success";s:257:"<img src="http://observatorio.webandpress.com/wp-content/uploads/2018/06/aceptado-icon-01.png" alt="aceptado" width="52" height="52" class="alignleft size-full" />Gracias, el correo fue enviado correctamente.             																																				";s:10:"db_support";i:1;s:6:"pinned";i:0;s:9:"hide_form";i:1;s:11:"check_honey";i:1;s:12:"avatar_field";s:0:"";s:9:"form_ajax";i:1;s:15:"custom_callback";s:0:"";s:11:"layout_grid";a:2:{s:6:"fields";a:5:{s:11:"fld_1182857";s:3:"1:1";s:11:"fld_9020497";s:3:"1:1";s:11:"fld_3421996";s:3:"2:1";s:11:"fld_4093740";s:3:"3:1";s:11:"fld_6033805";s:3:"4:1";}s:9:"structure";s:11:"12|12|12|12";}s:6:"fields";a:5:{s:11:"fld_1182857";a:8:{s:2:"ID";s:11:"fld_1182857";s:4:"type";s:4:"text";s:5:"label";s:6:"Nombre";s:4:"slug";s:6:"nombre";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:7:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:13:"type_override";s:4:"text";s:4:"mask";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_9020497";a:8:{s:2:"ID";s:11:"fld_9020497";s:4:"type";s:8:"dropdown";s:5:"label";s:6:"Asunto";s:4:"slug";s:12:"departamento";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:15:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:11:"show_values";i:1;s:6:"option";a:4:{s:10:"opt1259417";a:3:{s:10:"calc_value";i:1;s:5:"value";s:5:"Dudas";s:5:"label";s:5:"Dudas";}s:10:"opt1503008";a:3:{s:10:"calc_value";i:1;s:5:"value";s:10:"Sugerencia";s:5:"label";s:11:"Sugerencias";}s:10:"opt1716407";a:3:{s:10:"calc_value";i:1;s:5:"value";s:6:"Quejas";s:5:"label";s:6:"Quejas";}s:10:"opt1766768";a:3:{s:10:"calc_value";i:1;s:5:"value";s:4:"Otro";s:5:"label";s:4:"Otro";}}s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_3421996";a:8:{s:2:"ID";s:11:"fld_3421996";s:4:"type";s:5:"email";s:5:"label";s:6:"Correo";s:4:"slug";s:5:"email";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:5:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_4093740";a:8:{s:2:"ID";s:11:"fld_4093740";s:4:"type";s:9:"paragraph";s:5:"label";s:11:"Comentarios";s:4:"slug";s:11:"comentarios";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:6:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";i:3;s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_6033805";a:7:{s:2:"ID";s:11:"fld_6033805";s:4:"type";s:6:"button";s:5:"label";s:6:"Enviar";s:4:"slug";s:6:"enviar";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:4:"type";s:6:"submit";s:5:"class";s:15:"btn btn-default";s:6:"target";s:0:"";}}}s:10:"page_names";a:1:{i:0;s:6:"Page 1";}s:6:"mailer";a:9:{s:9:"on_insert";i:1;s:11:"sender_name";s:8:"%nombre%";s:12:"sender_email";s:40:"formulario@observatoriodelalaguna.org.mx";s:8:"reply_to";s:38:"contacto@observatoriodelalaguna.org.mx";s:10:"email_type";s:4:"html";s:10:"recipients";s:38:"contacto@observatoriodelalaguna.org.mx";s:6:"bcc_to";s:0:"";s:13:"email_subject";s:55:"Formulario / %departamento% / Observatorio de La Laguna";s:13:"email_message";s:325:"A continuación, los datos del formulario de contacto en <strong>www.observatoriodelalaguna.org.mx</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"processors";a:1:{s:11:"fp_78727378";a:5:{s:2:"ID";s:11:"fp_78727378";s:8:"runtimes";a:1:{s:6:"insert";i:1;}s:4:"type";s:14:"auto_responder";s:6:"config";a:9:{s:11:"sender_name";s:25:"Observatorio de La Laguna";s:12:"sender_email";s:38:"contacto@observatoriodelalaguna.org.mx";s:8:"reply_to";s:0:"";s:2:"cc";s:0:"";s:3:"bcc";s:0:"";s:7:"subject";s:46:"Observatorio de La Laguna / Tu correo recibido";s:14:"recipient_name";s:8:"%nombre%";s:15:"recipient_email";s:7:"%email%";s:7:"message";s:336:"A continuación, los datos recibidos. <strong>www.observatoriodelalaguna.org.mx
</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>SKU: </strong>%sku%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"conditions";a:1:{s:4:"type";s:0:"";}}}s:8:"antispam";a:2:{s:11:"sender_name";s:0:"";s:12:"sender_email";s:0:"";}s:18:"conditional_groups";a:1:{s:15:"_open_condition";s:0:"";}s:8:"settings";a:1:{s:10:"responsive";a:1:{s:11:"break_point";s:2:"sm";}}s:24:"privacy_exporter_enabled";b:0;s:7:"version";s:7:"1.7.1.4";}');
INSERT INTO webandpr_vvTjz1Bk.w47fa_cf_forms (id, form_id, type, config) VALUES (10, 'CF55ccb68ca64c0', 'revision', 'a:23:{s:13:"_last_updated";s:31:"Tue, 12 Jun 2018 03:56:10 +0000";s:2:"ID";s:15:"CF55ccb68ca64c0";s:10:"cf_version";s:7:"1.7.1.4";s:4:"name";s:8:"Contacto";s:10:"scroll_top";i:0;s:7:"success";s:257:"<img src="http://observatorio.webandpress.com/wp-content/uploads/2018/06/aceptado-icon-01.png" alt="aceptado" width="52" height="52" class="alignleft size-full" />Gracias, el correo fue enviado correctamente.             																																				";s:10:"db_support";i:1;s:6:"pinned";i:0;s:9:"hide_form";i:1;s:11:"check_honey";i:1;s:12:"avatar_field";s:0:"";s:9:"form_ajax";i:1;s:15:"custom_callback";s:0:"";s:11:"layout_grid";a:2:{s:6:"fields";a:5:{s:11:"fld_1182857";s:3:"1:1";s:11:"fld_9020497";s:3:"1:1";s:11:"fld_3421996";s:3:"2:1";s:11:"fld_4093740";s:3:"3:1";s:11:"fld_6033805";s:3:"4:1";}s:9:"structure";s:11:"12|12|12|12";}s:6:"fields";a:5:{s:11:"fld_1182857";a:8:{s:2:"ID";s:11:"fld_1182857";s:4:"type";s:4:"text";s:5:"label";s:6:"Nombre";s:4:"slug";s:6:"nombre";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:7:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:13:"type_override";s:4:"text";s:4:"mask";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_9020497";a:8:{s:2:"ID";s:11:"fld_9020497";s:4:"type";s:8:"dropdown";s:5:"label";s:6:"Asunto";s:4:"slug";s:12:"departamento";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:15:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:11:"show_values";i:1;s:6:"option";a:4:{s:10:"opt1259417";a:3:{s:10:"calc_value";i:1;s:5:"value";s:5:"Dudas";s:5:"label";s:5:"Dudas";}s:10:"opt1503008";a:3:{s:10:"calc_value";i:1;s:5:"value";s:10:"Sugerencia";s:5:"label";s:11:"Sugerencias";}s:10:"opt1716407";a:3:{s:10:"calc_value";i:1;s:5:"value";s:6:"Quejas";s:5:"label";s:6:"Quejas";}s:10:"opt1766768";a:3:{s:10:"calc_value";i:1;s:5:"value";s:4:"Otro";s:5:"label";s:4:"Otro";}}s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_3421996";a:8:{s:2:"ID";s:11:"fld_3421996";s:4:"type";s:5:"email";s:5:"label";s:6:"Correo";s:4:"slug";s:5:"email";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:5:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_4093740";a:8:{s:2:"ID";s:11:"fld_4093740";s:4:"type";s:9:"paragraph";s:5:"label";s:11:"Comentarios";s:4:"slug";s:11:"comentarios";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:6:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";i:3;s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_6033805";a:7:{s:2:"ID";s:11:"fld_6033805";s:4:"type";s:6:"button";s:5:"label";s:6:"Enviar";s:4:"slug";s:6:"enviar";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:4:"type";s:6:"submit";s:5:"class";s:15:"btn btn-default";s:6:"target";s:0:"";}}}s:10:"page_names";a:1:{i:0;s:6:"Page 1";}s:6:"mailer";a:9:{s:9:"on_insert";i:1;s:11:"sender_name";s:8:"%nombre%";s:12:"sender_email";s:40:"formulario@observatoriodelalaguna.org.mx";s:8:"reply_to";s:38:"contacto@observatoriodelalaguna.org.mx";s:10:"email_type";s:4:"html";s:10:"recipients";s:25:"albertotorres@outlook.com";s:6:"bcc_to";s:0:"";s:13:"email_subject";s:55:"Formulario / %departamento% / Observatorio de La Laguna";s:13:"email_message";s:325:"A continuación, los datos del formulario de contacto en <strong>www.observatoriodelalaguna.org.mx</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"processors";a:1:{s:11:"fp_78727378";a:5:{s:2:"ID";s:11:"fp_78727378";s:8:"runtimes";a:1:{s:6:"insert";i:1;}s:4:"type";s:14:"auto_responder";s:6:"config";a:9:{s:11:"sender_name";s:25:"Observatorio de La Laguna";s:12:"sender_email";s:38:"contacto@observatoriodelalaguna.org.mx";s:8:"reply_to";s:0:"";s:2:"cc";s:0:"";s:3:"bcc";s:0:"";s:7:"subject";s:46:"Observatorio de La Laguna / Tu correo recibido";s:14:"recipient_name";s:8:"%nombre%";s:15:"recipient_email";s:7:"%email%";s:7:"message";s:336:"A continuación, los datos recibidos. <strong>www.observatoriodelalaguna.org.mx
</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>SKU: </strong>%sku%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"conditions";a:1:{s:4:"type";s:0:"";}}}s:8:"antispam";a:2:{s:11:"sender_name";s:0:"";s:12:"sender_email";s:0:"";}s:18:"conditional_groups";a:1:{s:15:"_open_condition";s:0:"";}s:8:"settings";a:1:{s:10:"responsive";a:1:{s:11:"break_point";s:2:"sm";}}s:24:"privacy_exporter_enabled";b:0;s:7:"version";s:7:"1.7.1.4";}');
INSERT INTO webandpr_vvTjz1Bk.w47fa_cf_forms (id, form_id, type, config) VALUES (11, 'CF55ccb68ca64c0', 'revision', 'a:23:{s:13:"_last_updated";s:31:"Tue, 12 Jun 2018 03:58:34 +0000";s:2:"ID";s:15:"CF55ccb68ca64c0";s:10:"cf_version";s:7:"1.7.1.4";s:4:"name";s:8:"Contacto";s:10:"scroll_top";i:0;s:7:"success";s:257:"<img src="http://observatorio.webandpress.com/wp-content/uploads/2018/06/aceptado-icon-01.png" alt="aceptado" width="52" height="52" class="alignleft size-full" />Gracias, el correo fue enviado correctamente.             																																				";s:10:"db_support";i:1;s:6:"pinned";i:0;s:9:"hide_form";i:1;s:11:"check_honey";i:1;s:12:"avatar_field";s:0:"";s:9:"form_ajax";i:1;s:15:"custom_callback";s:0:"";s:11:"layout_grid";a:2:{s:6:"fields";a:5:{s:11:"fld_1182857";s:3:"1:1";s:11:"fld_9020497";s:3:"1:1";s:11:"fld_3421996";s:3:"2:1";s:11:"fld_4093740";s:3:"3:1";s:11:"fld_6033805";s:3:"4:1";}s:9:"structure";s:11:"12|12|12|12";}s:6:"fields";a:5:{s:11:"fld_1182857";a:8:{s:2:"ID";s:11:"fld_1182857";s:4:"type";s:4:"text";s:5:"label";s:6:"Nombre";s:4:"slug";s:6:"nombre";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:7:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:13:"type_override";s:4:"text";s:4:"mask";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_9020497";a:8:{s:2:"ID";s:11:"fld_9020497";s:4:"type";s:8:"dropdown";s:5:"label";s:6:"Asunto";s:4:"slug";s:12:"departamento";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:15:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:11:"show_values";i:1;s:6:"option";a:4:{s:10:"opt1259417";a:3:{s:10:"calc_value";i:1;s:5:"value";s:5:"Dudas";s:5:"label";s:5:"Dudas";}s:10:"opt1503008";a:3:{s:10:"calc_value";i:1;s:5:"value";s:10:"Sugerencia";s:5:"label";s:11:"Sugerencias";}s:10:"opt1716407";a:3:{s:10:"calc_value";i:1;s:5:"value";s:6:"Quejas";s:5:"label";s:6:"Quejas";}s:10:"opt1766768";a:3:{s:10:"calc_value";i:1;s:5:"value";s:4:"Otro";s:5:"label";s:4:"Otro";}}s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_3421996";a:8:{s:2:"ID";s:11:"fld_3421996";s:4:"type";s:5:"email";s:5:"label";s:6:"Correo";s:4:"slug";s:5:"email";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:5:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_4093740";a:8:{s:2:"ID";s:11:"fld_4093740";s:4:"type";s:9:"paragraph";s:5:"label";s:11:"Comentarios";s:4:"slug";s:11:"comentarios";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:6:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";i:3;s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_6033805";a:7:{s:2:"ID";s:11:"fld_6033805";s:4:"type";s:6:"button";s:5:"label";s:6:"Enviar";s:4:"slug";s:6:"enviar";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:4:"type";s:6:"submit";s:5:"class";s:15:"btn btn-default";s:6:"target";s:0:"";}}}s:10:"page_names";a:1:{i:0;s:6:"Page 1";}s:6:"mailer";a:9:{s:9:"on_insert";i:1;s:11:"sender_name";s:8:"%nombre%";s:12:"sender_email";s:40:"formulario@observatoriodelalaguna.org.mx";s:8:"reply_to";s:38:"contacto@observatoriodelalaguna.org.mx";s:10:"email_type";s:4:"html";s:10:"recipients";s:25:"albertotorres@outlook.com";s:6:"bcc_to";s:0:"";s:13:"email_subject";s:55:"Formulario / %departamento% / Observatorio de La Laguna";s:13:"email_message";s:325:"A continuación, los datos del formulario de contacto en <strong>www.observatoriodelalaguna.org.mx</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"processors";a:1:{s:11:"fp_78727378";a:5:{s:2:"ID";s:11:"fp_78727378";s:8:"runtimes";a:1:{s:6:"insert";i:1;}s:4:"type";s:14:"auto_responder";s:6:"config";a:9:{s:11:"sender_name";s:25:"Observatorio de La Laguna";s:12:"sender_email";s:38:"contacto@observatoriodelalaguna.org.mx";s:8:"reply_to";s:0:"";s:2:"cc";s:0:"";s:3:"bcc";s:0:"";s:7:"subject";s:46:"Observatorio de La Laguna / Tu correo recibido";s:14:"recipient_name";s:8:"%nombre%";s:15:"recipient_email";s:7:"%email%";s:7:"message";s:336:"A continuación, los datos recibidos. <strong>www.observatoriodelalaguna.org.mx
</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>SKU: </strong>%sku%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"conditions";a:1:{s:4:"type";s:0:"";}}}s:8:"antispam";a:2:{s:11:"sender_name";s:0:"";s:12:"sender_email";s:0:"";}s:18:"conditional_groups";a:1:{s:15:"_open_condition";s:0:"";}s:8:"settings";a:1:{s:10:"responsive";a:1:{s:11:"break_point";s:2:"sm";}}s:24:"privacy_exporter_enabled";b:0;s:7:"version";s:7:"1.7.1.4";}');
INSERT INTO webandpr_vvTjz1Bk.w47fa_cf_forms (id, form_id, type, config) VALUES (12, 'CF55ccb68ca64c0', 'revision', 'a:23:{s:13:"_last_updated";s:31:"Tue, 12 Jun 2018 04:23:11 +0000";s:2:"ID";s:15:"CF55ccb68ca64c0";s:10:"cf_version";s:7:"1.7.1.4";s:4:"name";s:8:"Contacto";s:10:"scroll_top";i:0;s:7:"success";s:257:"<img src="http://observatorio.webandpress.com/wp-content/uploads/2018/06/aceptado-icon-01.png" alt="aceptado" width="52" height="52" class="alignleft size-full" />Gracias, el correo fue enviado correctamente.             																																				";s:10:"db_support";i:1;s:6:"pinned";i:0;s:9:"hide_form";i:1;s:11:"check_honey";i:1;s:12:"avatar_field";s:0:"";s:9:"form_ajax";i:1;s:15:"custom_callback";s:0:"";s:11:"layout_grid";a:2:{s:6:"fields";a:5:{s:11:"fld_1182857";s:3:"1:1";s:11:"fld_9020497";s:3:"1:1";s:11:"fld_3421996";s:3:"2:1";s:11:"fld_4093740";s:3:"3:1";s:11:"fld_6033805";s:3:"4:1";}s:9:"structure";s:11:"12|12|12|12";}s:6:"fields";a:5:{s:11:"fld_1182857";a:8:{s:2:"ID";s:11:"fld_1182857";s:4:"type";s:4:"text";s:5:"label";s:6:"Nombre";s:4:"slug";s:6:"nombre";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:7:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:13:"type_override";s:4:"text";s:4:"mask";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_9020497";a:8:{s:2:"ID";s:11:"fld_9020497";s:4:"type";s:8:"dropdown";s:5:"label";s:6:"Asunto";s:4:"slug";s:12:"departamento";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:15:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:11:"show_values";i:1;s:6:"option";a:4:{s:10:"opt1259417";a:3:{s:10:"calc_value";i:1;s:5:"value";s:5:"Dudas";s:5:"label";s:5:"Dudas";}s:10:"opt1503008";a:3:{s:10:"calc_value";i:1;s:5:"value";s:10:"Sugerencia";s:5:"label";s:11:"Sugerencias";}s:10:"opt1716407";a:3:{s:10:"calc_value";i:1;s:5:"value";s:6:"Quejas";s:5:"label";s:6:"Quejas";}s:10:"opt1766768";a:3:{s:10:"calc_value";i:1;s:5:"value";s:4:"Otro";s:5:"label";s:4:"Otro";}}s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_3421996";a:8:{s:2:"ID";s:11:"fld_3421996";s:4:"type";s:5:"email";s:5:"label";s:6:"Correo";s:4:"slug";s:5:"email";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:5:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_4093740";a:8:{s:2:"ID";s:11:"fld_4093740";s:4:"type";s:9:"paragraph";s:5:"label";s:11:"Comentarios";s:4:"slug";s:11:"comentarios";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:6:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";i:3;s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_6033805";a:7:{s:2:"ID";s:11:"fld_6033805";s:4:"type";s:6:"button";s:5:"label";s:6:"Enviar";s:4:"slug";s:6:"enviar";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:4:"type";s:6:"submit";s:5:"class";s:15:"btn btn-default";s:6:"target";s:0:"";}}}s:10:"page_names";a:1:{i:0;s:6:"Page 1";}s:6:"mailer";a:9:{s:9:"on_insert";i:1;s:11:"sender_name";s:8:"%nombre%";s:12:"sender_email";s:40:"formulario@observatoriodelalaguna.org.mx";s:8:"reply_to";s:38:"contacto@observatoriodelalaguna.org.mx";s:10:"email_type";s:4:"html";s:10:"recipients";s:25:"albertotorres@outlook.com";s:6:"bcc_to";s:0:"";s:13:"email_subject";s:55:"Formulario / %departamento% / Observatorio de La Laguna";s:13:"email_message";s:325:"A continuación, los datos del formulario de contacto en <strong>www.observatoriodelalaguna.org.mx</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"processors";a:1:{s:11:"fp_78727378";a:5:{s:2:"ID";s:11:"fp_78727378";s:8:"runtimes";a:1:{s:6:"insert";i:1;}s:4:"type";s:14:"auto_responder";s:6:"config";a:9:{s:11:"sender_name";s:25:"Observatorio de La Laguna";s:12:"sender_email";s:38:"contacto@observatoriodelalaguna.org.mx";s:8:"reply_to";s:0:"";s:2:"cc";s:0:"";s:3:"bcc";s:0:"";s:7:"subject";s:46:"Observatorio de La Laguna / Tu correo recibido";s:14:"recipient_name";s:8:"%nombre%";s:15:"recipient_email";s:7:"%email%";s:7:"message";s:307:"A continuación, los datos recibidos. <strong>www.observatoriodelalaguna.org.mx
</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"conditions";a:1:{s:4:"type";s:0:"";}}}s:8:"antispam";a:2:{s:11:"sender_name";s:0:"";s:12:"sender_email";s:0:"";}s:18:"conditional_groups";a:1:{s:15:"_open_condition";s:0:"";}s:8:"settings";a:1:{s:10:"responsive";a:1:{s:11:"break_point";s:2:"sm";}}s:24:"privacy_exporter_enabled";b:0;s:7:"version";s:7:"1.7.1.4";}');
INSERT INTO webandpr_vvTjz1Bk.w47fa_cf_forms (id, form_id, type, config) VALUES (13, 'CF55ccb68ca64c0', 'revision', 'a:23:{s:13:"_last_updated";s:31:"Tue, 26 Jun 2018 21:52:53 +0000";s:2:"ID";s:15:"CF55ccb68ca64c0";s:10:"cf_version";s:7:"1.7.1.4";s:4:"name";s:8:"Contacto";s:10:"scroll_top";i:0;s:7:"success";s:261:"<img src="http://observatoriodelalaguna.org.mx/wp-content/uploads/2018/06/aceptado-icon-01.png" alt="aceptado" width="52" height="52" class="alignleft size-full" />Gracias, el correo fue enviado correctamente.             																																							";s:10:"db_support";i:1;s:6:"pinned";i:0;s:9:"hide_form";i:1;s:11:"check_honey";i:1;s:12:"avatar_field";s:0:"";s:9:"form_ajax";i:1;s:15:"custom_callback";s:0:"";s:11:"layout_grid";a:2:{s:6:"fields";a:5:{s:11:"fld_1182857";s:3:"1:1";s:11:"fld_9020497";s:3:"1:1";s:11:"fld_3421996";s:3:"2:1";s:11:"fld_4093740";s:3:"3:1";s:11:"fld_6033805";s:3:"4:1";}s:9:"structure";s:11:"12|12|12|12";}s:6:"fields";a:5:{s:11:"fld_1182857";a:8:{s:2:"ID";s:11:"fld_1182857";s:4:"type";s:4:"text";s:5:"label";s:6:"Nombre";s:4:"slug";s:6:"nombre";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:7:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:13:"type_override";s:4:"text";s:4:"mask";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_9020497";a:8:{s:2:"ID";s:11:"fld_9020497";s:4:"type";s:8:"dropdown";s:5:"label";s:6:"Asunto";s:4:"slug";s:12:"departamento";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:15:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:11:"show_values";i:1;s:6:"option";a:4:{s:10:"opt1259417";a:3:{s:10:"calc_value";i:1;s:5:"value";s:5:"Dudas";s:5:"label";s:5:"Dudas";}s:10:"opt1503008";a:3:{s:10:"calc_value";i:1;s:5:"value";s:10:"Sugerencia";s:5:"label";s:11:"Sugerencias";}s:10:"opt1716407";a:3:{s:10:"calc_value";i:1;s:5:"value";s:6:"Quejas";s:5:"label";s:6:"Quejas";}s:10:"opt1766768";a:3:{s:10:"calc_value";i:1;s:5:"value";s:4:"Otro";s:5:"label";s:4:"Otro";}}s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_3421996";a:8:{s:2:"ID";s:11:"fld_3421996";s:4:"type";s:5:"email";s:5:"label";s:6:"Correo";s:4:"slug";s:5:"email";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:5:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_4093740";a:8:{s:2:"ID";s:11:"fld_4093740";s:4:"type";s:9:"paragraph";s:5:"label";s:11:"Comentarios";s:4:"slug";s:11:"comentarios";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:6:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";i:3;s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_6033805";a:7:{s:2:"ID";s:11:"fld_6033805";s:4:"type";s:6:"button";s:5:"label";s:6:"Enviar";s:4:"slug";s:6:"enviar";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:4:"type";s:6:"submit";s:5:"class";s:15:"btn btn-default";s:6:"target";s:0:"";}}}s:10:"page_names";a:1:{i:0;s:6:"Page 1";}s:6:"mailer";a:9:{s:9:"on_insert";i:1;s:11:"sender_name";s:8:"%nombre%";s:12:"sender_email";s:40:"formulario@observatoriodelalaguna.org.mx";s:8:"reply_to";s:38:"contacto@observatoriodelalaguna.org.mx";s:10:"email_type";s:4:"html";s:10:"recipients";s:25:"albertotorres@outlook.com";s:6:"bcc_to";s:0:"";s:13:"email_subject";s:55:"Formulario / %departamento% / Observatorio de La Laguna";s:13:"email_message";s:325:"A continuación, los datos del formulario de contacto en <strong>www.observatoriodelalaguna.org.mx</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"processors";a:1:{s:11:"fp_78727378";a:5:{s:2:"ID";s:11:"fp_78727378";s:8:"runtimes";a:1:{s:6:"insert";i:1;}s:4:"type";s:14:"auto_responder";s:6:"config";a:9:{s:11:"sender_name";s:25:"Observatorio de La Laguna";s:12:"sender_email";s:38:"contacto@observatoriodelalaguna.org.mx";s:8:"reply_to";s:0:"";s:2:"cc";s:0:"";s:3:"bcc";s:0:"";s:7:"subject";s:46:"Observatorio de La Laguna / Tu correo recibido";s:14:"recipient_name";s:8:"%nombre%";s:15:"recipient_email";s:7:"%email%";s:7:"message";s:307:"A continuación, los datos recibidos. <strong>www.observatoriodelalaguna.org.mx
</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"conditions";a:1:{s:4:"type";s:0:"";}}}s:8:"antispam";a:2:{s:11:"sender_name";s:0:"";s:12:"sender_email";s:0:"";}s:18:"conditional_groups";a:1:{s:15:"_open_condition";s:0:"";}s:8:"settings";a:1:{s:10:"responsive";a:1:{s:11:"break_point";s:2:"sm";}}s:24:"privacy_exporter_enabled";b:0;s:7:"version";s:7:"1.7.1.4";}');
INSERT INTO webandpr_vvTjz1Bk.w47fa_cf_forms (id, form_id, type, config) VALUES (14, 'CF55ccb68ca64c0', 'revision', 'a:23:{s:13:"_last_updated";s:31:"Tue, 26 Jun 2018 21:53:33 +0000";s:2:"ID";s:15:"CF55ccb68ca64c0";s:10:"cf_version";s:7:"1.7.1.4";s:4:"name";s:8:"Contacto";s:10:"scroll_top";i:0;s:7:"success";s:261:"<img src="http://observatoriodelalaguna.org.mx/wp-content/uploads/2018/06/aceptado-icon-01.png" alt="aceptado" width="52" height="52" class="alignleft size-full" />Gracias, el correo fue enviado correctamente.             																																							";s:10:"db_support";i:1;s:6:"pinned";i:0;s:9:"hide_form";i:1;s:11:"check_honey";i:1;s:12:"avatar_field";s:0:"";s:9:"form_ajax";i:1;s:15:"custom_callback";s:0:"";s:11:"layout_grid";a:2:{s:6:"fields";a:5:{s:11:"fld_1182857";s:3:"1:1";s:11:"fld_9020497";s:3:"1:1";s:11:"fld_3421996";s:3:"2:1";s:11:"fld_4093740";s:3:"3:1";s:11:"fld_6033805";s:3:"4:1";}s:9:"structure";s:11:"12|12|12|12";}s:6:"fields";a:5:{s:11:"fld_1182857";a:8:{s:2:"ID";s:11:"fld_1182857";s:4:"type";s:4:"text";s:5:"label";s:6:"Nombre";s:4:"slug";s:6:"nombre";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:7:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:13:"type_override";s:4:"text";s:4:"mask";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_9020497";a:8:{s:2:"ID";s:11:"fld_9020497";s:4:"type";s:8:"dropdown";s:5:"label";s:6:"Asunto";s:4:"slug";s:12:"departamento";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:15:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:11:"show_values";i:1;s:6:"option";a:4:{s:10:"opt1259417";a:3:{s:10:"calc_value";i:1;s:5:"value";s:5:"Dudas";s:5:"label";s:5:"Dudas";}s:10:"opt1503008";a:3:{s:10:"calc_value";i:1;s:5:"value";s:10:"Sugerencia";s:5:"label";s:11:"Sugerencias";}s:10:"opt1716407";a:3:{s:10:"calc_value";i:1;s:5:"value";s:6:"Quejas";s:5:"label";s:6:"Quejas";}s:10:"opt1766768";a:3:{s:10:"calc_value";i:1;s:5:"value";s:4:"Otro";s:5:"label";s:4:"Otro";}}s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_3421996";a:8:{s:2:"ID";s:11:"fld_3421996";s:4:"type";s:5:"email";s:5:"label";s:6:"Correo";s:4:"slug";s:5:"email";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:5:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_4093740";a:8:{s:2:"ID";s:11:"fld_4093740";s:4:"type";s:9:"paragraph";s:5:"label";s:11:"Comentarios";s:4:"slug";s:11:"comentarios";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:6:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";i:3;s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_6033805";a:7:{s:2:"ID";s:11:"fld_6033805";s:4:"type";s:6:"button";s:5:"label";s:6:"Enviar";s:4:"slug";s:6:"enviar";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:4:"type";s:6:"submit";s:5:"class";s:15:"btn btn-default";s:6:"target";s:0:"";}}}s:10:"page_names";a:1:{i:0;s:6:"Page 1";}s:6:"mailer";a:9:{s:9:"on_insert";i:1;s:11:"sender_name";s:8:"%nombre%";s:12:"sender_email";s:40:"formulario@observatoriodelalaguna.org.mx";s:8:"reply_to";s:7:"%email%";s:10:"email_type";s:4:"html";s:10:"recipients";s:25:"albertotorres@outlook.com";s:6:"bcc_to";s:0:"";s:13:"email_subject";s:55:"Formulario / %departamento% / Observatorio de La Laguna";s:13:"email_message";s:325:"A continuación, los datos del formulario de contacto en <strong>www.observatoriodelalaguna.org.mx</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"processors";a:1:{s:11:"fp_78727378";a:5:{s:2:"ID";s:11:"fp_78727378";s:8:"runtimes";a:1:{s:6:"insert";i:1;}s:4:"type";s:14:"auto_responder";s:6:"config";a:9:{s:11:"sender_name";s:25:"Observatorio de La Laguna";s:12:"sender_email";s:38:"contacto@observatoriodelalaguna.org.mx";s:8:"reply_to";s:0:"";s:2:"cc";s:0:"";s:3:"bcc";s:0:"";s:7:"subject";s:46:"Observatorio de La Laguna / Tu correo recibido";s:14:"recipient_name";s:8:"%nombre%";s:15:"recipient_email";s:7:"%email%";s:7:"message";s:307:"A continuación, los datos recibidos. <strong>www.observatoriodelalaguna.org.mx
</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"conditions";a:1:{s:4:"type";s:0:"";}}}s:8:"antispam";a:2:{s:11:"sender_name";s:0:"";s:12:"sender_email";s:0:"";}s:18:"conditional_groups";a:1:{s:15:"_open_condition";s:0:"";}s:8:"settings";a:1:{s:10:"responsive";a:1:{s:11:"break_point";s:2:"sm";}}s:24:"privacy_exporter_enabled";b:0;s:7:"version";s:7:"1.7.1.4";}');
INSERT INTO webandpr_vvTjz1Bk.w47fa_cf_forms (id, form_id, type, config) VALUES (15, 'CF55ccb68ca64c0', 'revision', 'a:23:{s:13:"_last_updated";s:31:"Tue, 26 Jun 2018 21:54:02 +0000";s:2:"ID";s:15:"CF55ccb68ca64c0";s:10:"cf_version";s:7:"1.7.1.4";s:4:"name";s:8:"Contacto";s:10:"scroll_top";i:0;s:7:"success";s:261:"<img src="http://observatoriodelalaguna.org.mx/wp-content/uploads/2018/06/aceptado-icon-01.png" alt="aceptado" width="52" height="52" class="alignleft size-full" />Gracias, el correo fue enviado correctamente.             																																							";s:10:"db_support";i:1;s:6:"pinned";i:0;s:9:"hide_form";i:1;s:11:"check_honey";i:1;s:12:"avatar_field";s:0:"";s:9:"form_ajax";i:1;s:15:"custom_callback";s:0:"";s:11:"layout_grid";a:2:{s:6:"fields";a:5:{s:11:"fld_1182857";s:3:"1:1";s:11:"fld_9020497";s:3:"1:1";s:11:"fld_3421996";s:3:"2:1";s:11:"fld_4093740";s:3:"3:1";s:11:"fld_6033805";s:3:"4:1";}s:9:"structure";s:11:"12|12|12|12";}s:6:"fields";a:5:{s:11:"fld_1182857";a:8:{s:2:"ID";s:11:"fld_1182857";s:4:"type";s:4:"text";s:5:"label";s:6:"Nombre";s:4:"slug";s:6:"nombre";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:7:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:13:"type_override";s:4:"text";s:4:"mask";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_9020497";a:8:{s:2:"ID";s:11:"fld_9020497";s:4:"type";s:8:"dropdown";s:5:"label";s:6:"Asunto";s:4:"slug";s:12:"departamento";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:15:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:11:"show_values";i:1;s:6:"option";a:4:{s:10:"opt1259417";a:3:{s:10:"calc_value";i:1;s:5:"value";s:5:"Dudas";s:5:"label";s:5:"Dudas";}s:10:"opt1503008";a:3:{s:10:"calc_value";i:1;s:5:"value";s:10:"Sugerencia";s:5:"label";s:11:"Sugerencias";}s:10:"opt1716407";a:3:{s:10:"calc_value";i:1;s:5:"value";s:6:"Quejas";s:5:"label";s:6:"Quejas";}s:10:"opt1766768";a:3:{s:10:"calc_value";i:1;s:5:"value";s:4:"Otro";s:5:"label";s:4:"Otro";}}s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_3421996";a:8:{s:2:"ID";s:11:"fld_3421996";s:4:"type";s:5:"email";s:5:"label";s:6:"Correo";s:4:"slug";s:5:"email";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:5:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_4093740";a:8:{s:2:"ID";s:11:"fld_4093740";s:4:"type";s:9:"paragraph";s:5:"label";s:11:"Comentarios";s:4:"slug";s:11:"comentarios";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:6:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";i:3;s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_6033805";a:7:{s:2:"ID";s:11:"fld_6033805";s:4:"type";s:6:"button";s:5:"label";s:6:"Enviar";s:4:"slug";s:6:"enviar";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:4:"type";s:6:"submit";s:5:"class";s:15:"btn btn-default";s:6:"target";s:0:"";}}}s:10:"page_names";a:1:{i:0;s:6:"Page 1";}s:6:"mailer";a:9:{s:9:"on_insert";i:1;s:11:"sender_name";s:8:"%nombre%";s:12:"sender_email";s:40:"formulario@observatoriodelalaguna.org.mx";s:8:"reply_to";s:7:"%email%";s:10:"email_type";s:4:"html";s:10:"recipients";s:25:"albertotorres@outlook.com";s:6:"bcc_to";s:0:"";s:13:"email_subject";s:55:"Formulario / %departamento% / Observatorio de La Laguna";s:13:"email_message";s:325:"A continuación, los datos del formulario de contacto en <strong>www.observatoriodelalaguna.org.mx</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"processors";a:1:{s:11:"fp_78727378";a:5:{s:2:"ID";s:11:"fp_78727378";s:8:"runtimes";a:1:{s:6:"insert";i:1;}s:4:"type";s:14:"auto_responder";s:6:"config";a:9:{s:11:"sender_name";s:25:"Observatorio de La Laguna";s:12:"sender_email";s:26:"contacto@ccilaguna.org.mx ";s:8:"reply_to";s:0:"";s:2:"cc";s:0:"";s:3:"bcc";s:0:"";s:7:"subject";s:46:"Observatorio de La Laguna / Tu correo recibido";s:14:"recipient_name";s:8:"%nombre%";s:15:"recipient_email";s:7:"%email%";s:7:"message";s:307:"A continuación, los datos recibidos. <strong>www.observatoriodelalaguna.org.mx
</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"conditions";a:1:{s:4:"type";s:0:"";}}}s:8:"antispam";a:2:{s:11:"sender_name";s:0:"";s:12:"sender_email";s:0:"";}s:18:"conditional_groups";a:1:{s:15:"_open_condition";s:0:"";}s:8:"settings";a:1:{s:10:"responsive";a:1:{s:11:"break_point";s:2:"sm";}}s:24:"privacy_exporter_enabled";b:0;s:7:"version";s:7:"1.7.1.4";}');
INSERT INTO webandpr_vvTjz1Bk.w47fa_cf_forms (id, form_id, type, config) VALUES (16, 'CF55ccb68ca64c0', 'revision', 'a:23:{s:13:"_last_updated";s:31:"Tue, 26 Jun 2018 22:01:22 +0000";s:2:"ID";s:15:"CF55ccb68ca64c0";s:10:"cf_version";s:7:"1.7.1.4";s:4:"name";s:8:"Contacto";s:10:"scroll_top";i:0;s:7:"success";s:264:"<img src="http://observatoriodelalaguna.org.mx/wp-content/uploads/2018/06/aceptado-icon-01.png" alt="aceptado" width="52" height="52" class="alignleft size-full" />Gracias, el correo fue enviado correctamente.             																																										";s:10:"db_support";i:1;s:6:"pinned";i:0;s:9:"hide_form";i:1;s:11:"check_honey";i:1;s:12:"avatar_field";s:0:"";s:9:"form_ajax";i:1;s:15:"custom_callback";s:0:"";s:11:"layout_grid";a:2:{s:6:"fields";a:5:{s:11:"fld_1182857";s:3:"1:1";s:11:"fld_9020497";s:3:"1:1";s:11:"fld_3421996";s:3:"2:1";s:11:"fld_4093740";s:3:"3:1";s:11:"fld_6033805";s:3:"4:1";}s:9:"structure";s:11:"12|12|12|12";}s:6:"fields";a:5:{s:11:"fld_1182857";a:8:{s:2:"ID";s:11:"fld_1182857";s:4:"type";s:4:"text";s:5:"label";s:6:"Nombre";s:4:"slug";s:6:"nombre";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:7:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:13:"type_override";s:4:"text";s:4:"mask";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_9020497";a:8:{s:2:"ID";s:11:"fld_9020497";s:4:"type";s:8:"dropdown";s:5:"label";s:6:"Asunto";s:4:"slug";s:12:"departamento";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:15:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:11:"show_values";i:1;s:6:"option";a:4:{s:10:"opt1259417";a:3:{s:10:"calc_value";i:1;s:5:"value";s:5:"Dudas";s:5:"label";s:5:"Dudas";}s:10:"opt1503008";a:3:{s:10:"calc_value";i:1;s:5:"value";s:10:"Sugerencia";s:5:"label";s:11:"Sugerencias";}s:10:"opt1716407";a:3:{s:10:"calc_value";i:1;s:5:"value";s:6:"Quejas";s:5:"label";s:6:"Quejas";}s:10:"opt1766768";a:3:{s:10:"calc_value";i:1;s:5:"value";s:4:"Otro";s:5:"label";s:4:"Otro";}}s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_3421996";a:8:{s:2:"ID";s:11:"fld_3421996";s:4:"type";s:5:"email";s:5:"label";s:6:"Correo";s:4:"slug";s:5:"email";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:5:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_4093740";a:8:{s:2:"ID";s:11:"fld_4093740";s:4:"type";s:9:"paragraph";s:5:"label";s:11:"Comentarios";s:4:"slug";s:11:"comentarios";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:6:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";i:3;s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_6033805";a:7:{s:2:"ID";s:11:"fld_6033805";s:4:"type";s:6:"button";s:5:"label";s:6:"Enviar";s:4:"slug";s:6:"enviar";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:4:"type";s:6:"submit";s:5:"class";s:15:"btn btn-default";s:6:"target";s:0:"";}}}s:10:"page_names";a:1:{i:0;s:6:"Page 1";}s:6:"mailer";a:9:{s:9:"on_insert";i:1;s:11:"sender_name";s:8:"%nombre%";s:12:"sender_email";s:40:"formulario@observatoriodelalaguna.org.mx";s:8:"reply_to";s:7:"%email%";s:10:"email_type";s:4:"html";s:10:"recipients";s:25:"albertotorres@outlook.com";s:6:"bcc_to";s:0:"";s:13:"email_subject";s:55:"Formulario / %departamento% / Observatorio de La Laguna";s:13:"email_message";s:325:"A continuación, los datos del formulario de contacto en <strong>www.observatoriodelalaguna.org.mx</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"processors";a:1:{s:11:"fp_78727378";a:5:{s:2:"ID";s:11:"fp_78727378";s:8:"runtimes";a:1:{s:6:"insert";i:1;}s:4:"type";s:14:"auto_responder";s:6:"config";a:9:{s:11:"sender_name";s:3:"CCI";s:12:"sender_email";s:26:"contacto@ccilaguna.org.mx ";s:8:"reply_to";s:0:"";s:2:"cc";s:0:"";s:3:"bcc";s:0:"";s:7:"subject";s:46:"Observatorio de La Laguna / Tu correo recibido";s:14:"recipient_name";s:8:"%nombre%";s:15:"recipient_email";s:7:"%email%";s:7:"message";s:307:"A continuación, los datos recibidos. <strong>www.observatoriodelalaguna.org.mx
</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"conditions";a:1:{s:4:"type";s:0:"";}}}s:8:"antispam";a:2:{s:11:"sender_name";s:0:"";s:12:"sender_email";s:0:"";}s:18:"conditional_groups";a:1:{s:15:"_open_condition";s:0:"";}s:8:"settings";a:1:{s:10:"responsive";a:1:{s:11:"break_point";s:2:"sm";}}s:24:"privacy_exporter_enabled";b:0;s:7:"version";s:7:"1.7.1.4";}');
INSERT INTO webandpr_vvTjz1Bk.w47fa_cf_forms (id, form_id, type, config) VALUES (17, 'CF55ccb68ca64c0', 'primary', 'a:23:{s:13:"_last_updated";s:31:"Tue, 26 Jun 2018 22:01:44 +0000";s:2:"ID";s:15:"CF55ccb68ca64c0";s:10:"cf_version";s:7:"1.7.1.4";s:4:"name";s:8:"Contacto";s:10:"scroll_top";i:0;s:7:"success";s:264:"<img src="http://observatoriodelalaguna.org.mx/wp-content/uploads/2018/06/aceptado-icon-01.png" alt="aceptado" width="52" height="52" class="alignleft size-full" />Gracias, el correo fue enviado correctamente.             																																										";s:10:"db_support";i:1;s:6:"pinned";i:0;s:9:"hide_form";i:1;s:11:"check_honey";i:1;s:12:"avatar_field";s:0:"";s:9:"form_ajax";i:1;s:15:"custom_callback";s:0:"";s:11:"layout_grid";a:2:{s:6:"fields";a:5:{s:11:"fld_1182857";s:3:"1:1";s:11:"fld_9020497";s:3:"1:1";s:11:"fld_3421996";s:3:"2:1";s:11:"fld_4093740";s:3:"3:1";s:11:"fld_6033805";s:3:"4:1";}s:9:"structure";s:11:"12|12|12|12";}s:6:"fields";a:5:{s:11:"fld_1182857";a:8:{s:2:"ID";s:11:"fld_1182857";s:4:"type";s:4:"text";s:5:"label";s:6:"Nombre";s:4:"slug";s:6:"nombre";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:7:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:13:"type_override";s:4:"text";s:4:"mask";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_9020497";a:8:{s:2:"ID";s:11:"fld_9020497";s:4:"type";s:8:"dropdown";s:5:"label";s:6:"Asunto";s:4:"slug";s:12:"departamento";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:15:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:14:"default_option";s:0:"";s:9:"auto_type";s:0:"";s:8:"taxonomy";s:8:"category";s:9:"post_type";s:4:"post";s:11:"value_field";s:4:"name";s:11:"orderby_tax";s:4:"name";s:12:"orderby_post";s:4:"name";s:5:"order";s:3:"ASC";s:7:"default";s:0:"";s:11:"show_values";i:1;s:6:"option";a:4:{s:10:"opt1259417";a:3:{s:10:"calc_value";i:1;s:5:"value";s:5:"Dudas";s:5:"label";s:5:"Dudas";}s:10:"opt1503008";a:3:{s:10:"calc_value";i:1;s:5:"value";s:10:"Sugerencia";s:5:"label";s:11:"Sugerencias";}s:10:"opt1716407";a:3:{s:10:"calc_value";i:1;s:5:"value";s:6:"Quejas";s:5:"label";s:6:"Quejas";}s:10:"opt1766768";a:3:{s:10:"calc_value";i:1;s:5:"value";s:4:"Otro";s:5:"label";s:4:"Otro";}}s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_3421996";a:8:{s:2:"ID";s:11:"fld_3421996";s:4:"type";s:5:"email";s:5:"label";s:6:"Correo";s:4:"slug";s:5:"email";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:5:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_4093740";a:8:{s:2:"ID";s:11:"fld_4093740";s:4:"type";s:9:"paragraph";s:5:"label";s:11:"Comentarios";s:4:"slug";s:11:"comentarios";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:8:"required";i:1;s:7:"caption";s:0:"";s:6:"config";a:6:{s:12:"custom_class";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";i:3;s:7:"default";s:0:"";s:16:"email_identifier";i:0;s:22:"personally_identifying";i:0;}}s:11:"fld_6033805";a:7:{s:2:"ID";s:11:"fld_6033805";s:4:"type";s:6:"button";s:5:"label";s:6:"Enviar";s:4:"slug";s:6:"enviar";s:10:"conditions";a:1:{s:4:"type";s:0:"";}s:7:"caption";s:0:"";s:6:"config";a:4:{s:12:"custom_class";s:0:"";s:4:"type";s:6:"submit";s:5:"class";s:15:"btn btn-default";s:6:"target";s:0:"";}}}s:10:"page_names";a:1:{i:0;s:6:"Page 1";}s:6:"mailer";a:9:{s:9:"on_insert";i:1;s:11:"sender_name";s:8:"%nombre%";s:12:"sender_email";s:40:"formulario@observatoriodelalaguna.org.mx";s:8:"reply_to";s:7:"%email%";s:10:"email_type";s:4:"html";s:10:"recipients";s:25:"contacto@ccilaguna.org.mx";s:6:"bcc_to";s:0:"";s:13:"email_subject";s:55:"Formulario / %departamento% / Observatorio de La Laguna";s:13:"email_message";s:325:"A continuación, los datos del formulario de contacto en <strong>www.observatoriodelalaguna.org.mx</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"processors";a:1:{s:11:"fp_78727378";a:5:{s:2:"ID";s:11:"fp_78727378";s:8:"runtimes";a:1:{s:6:"insert";i:1;}s:4:"type";s:14:"auto_responder";s:6:"config";a:9:{s:11:"sender_name";s:3:"CCI";s:12:"sender_email";s:26:"contacto@ccilaguna.org.mx ";s:8:"reply_to";s:0:"";s:2:"cc";s:0:"";s:3:"bcc";s:0:"";s:7:"subject";s:46:"Observatorio de La Laguna / Tu correo recibido";s:14:"recipient_name";s:8:"%nombre%";s:15:"recipient_email";s:7:"%email%";s:7:"message";s:307:"A continuación, los datos recibidos. <strong>www.observatoriodelalaguna.org.mx
</strong>

&nbsp;

<strong>Nombre: </strong> %nombre%

<strong>Email: </strong> %email%

<strong>Asunto: </strong>%departamento%

<strong>Comentarios: </strong> %comentarios%

&nbsp;
<h3><strong>{date:Y-m-d H:i:s}</strong></h3>";}s:10:"conditions";a:1:{s:4:"type";s:0:"";}}}s:8:"antispam";a:2:{s:11:"sender_name";s:0:"";s:12:"sender_email";s:0:"";}s:18:"conditional_groups";a:1:{s:15:"_open_condition";s:0:"";}s:8:"settings";a:1:{s:10:"responsive";a:1:{s:11:"break_point";s:2:"sm";}}s:24:"privacy_exporter_enabled";b:0;s:7:"version";s:7:"1.7.1.4";}');